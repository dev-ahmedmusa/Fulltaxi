<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\DocumentMaster;

class DocumentMasterController extends Controller
{
   
    public function index()
    {
        $documents = DocumentMaster::all();
        return view('Dashboard.document.index',compact('documents'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('Dashboard.document.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        
        //dd($request);
        DocumentMaster::create([
            'name' => $request->name,
            'expire_valid_for' => $request->expire_valid_for,
            'doc_type' => $request->doc_type,
        ]);
   

        session()->flash('add');
        return redirect()->route('document.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(DocumentMaster $category)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(DocumentMaster $category)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        $section = DocumentMaster::findOrFail($request->id);
        $section->update([
            'name' => $request->input('name'),
            'note' => $request->input('note'),
        ]);
        session()->flash('edit');
        return redirect()->route('document.index');
    }


    public function destroy($request)
    {
        DocumentMaster::findOrFail($request->id)->delete();
        session()->flash('delete');
        return redirect()->route('document.index');
    }

}