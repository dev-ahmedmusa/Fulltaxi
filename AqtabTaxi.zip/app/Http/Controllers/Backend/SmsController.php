<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SmsController extends Controller
{
    public static function send_message($text, $mobile_number)
    {
    //     $mobile_number = "249".$mobile_number;
        
      

    //     //$output = $results->getBody();
        

    //     return $output;
     }
}
