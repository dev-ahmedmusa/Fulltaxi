<?php

namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;

use App\Models\Service;
use Illuminate\Http\Request;

class ServiceController extends Controller
{
     /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $services = Service::all();
        return view('Dashboard.service.index',compact('services'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('Dashboard.service.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
    try{
    Service::create([
            'name' => $request->input('name'),
            'note' => $request->input('note'),
        ]);
   
      
        toastr()->success(trans('messages.success'));
        return redirect()->route('service');

    }

    catch (\Exception $e){
      
        return redirect()->back()->withErrors(['error' => $e->getMessage()]);
    }

    }

    /**
     * Display the specified resource.
     */
    public function show(Service $ServiceType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Service $ServiceType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        $section = Service::findOrFail($request->id);
        $section->update([
            'name' => $request->input('name'),
            'note' => $request->input('note'),
        ]);
        session()->flash('edit');
        return redirect()->route('service.index');
    }


    public function destroy($request)
    {
        Service::findOrFail($request->id)->delete();
        session()->flash('delete');
        return redirect()->route('service.index');
    }
}

