<?php

namespace Database\Seeders;

use App\Models\Service;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ServiceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('services')->delete();
        // DB::table('services')->insert([
        //     'name' =>  ['en' => 'Taxi', 'ar'=> "تاكسي"],
        //     'note' =>  ['en' => 'For Transport', 'ar'=> "لتوصيل الافراد"],
           
        // ]);
        $data = [
          
            'en' => ['name' => 'Taxi'],
            'ar' => ['name' => 'تاكسي'],
            'en' => ['note' => 'Transport'],
            'ar' => ['note' => 'توصيل الافراد'],
          ];
        Service::create($data);
          
          

   
    }
}
